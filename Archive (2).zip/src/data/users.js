const users = [
	// {id::'34',userName:'basit898',password:'123',firstName:'Basit',lastName:'Ali'},
	// {id:'09',userName:'johndoe',password:'1234',firstName:'John',lastName:'Doe'},
	// {id:'55',userName:'erick',password:'9999',firstName:'Erick',lastName:'Groom'},
	{ id: '23', userName: 'basit898', password: '123' },
	{ id: '92', userName: 'johndoe', password: '900' },
	{ id: '55', userName: 'david43', password: '777' },
];

export default users;
